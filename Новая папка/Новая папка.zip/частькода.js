const products = [
    { id: 1, img: 'Images/bcaa.png', name: 'product1', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 2, img: 'Images/bcaa.png', name: 'Product2', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 3, img: 'Images/bcaa.png', name: 'Product3', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 4, img: 'Images/bcaa.png', name: 'Product4', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 5, img: 'Images/bcaa.png', name: 'Product5', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 6, img: 'Images/bcaa.png', name: 'Product6', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 7, img: 'Images/bcaa.png', name: 'Product7', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 8, img: 'Images/bcaa.png', name: 'Product8', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 9, img: 'Images/bcaa.png', name: 'Product9', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 10, img: 'Images/bcaa.png', name: 'Product10', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 11, img: 'Images/bcaa.png', name: 'Product11', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 12, img: 'Images/bcaa.png', name: 'Product12', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 13, img: 'Images/bcaa.png', name: 'Product13', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 14, img: 'Images/bcaa.png', name: 'Product14', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 15, img: 'Images/bcaa.png', name: 'Product15', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    { id: 16, img: 'Images/bcaa.png', name: 'Product16', img_1: "Images/e46c675c36e63f75d02c011720556291f8b3141a (1).png"},
    // Добавьте остальные товары по аналогии
];

// Функция для отображения товаров
function renderProducts() {
    const productGrid = document.getElementById('productGrid');
    productGrid.innerHTML = '';

    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';

        const img = document.createElement('img');
        img.src = product.img

        const addBtn = document.createElement('button');
        addBtn.className = 'add-btn';
        addBtn.textContent = 'ДОБАВИТЬ В 🛒';

        productCard.appendChild(img);
        productCard.appendChild(addBtn);
        productGrid.appendChild(productCard);
    });
}

// Функция поиска товаров (пример)
function searchProducts() {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const filteredProducts = products.filter(product => 
        product.name.toLowerCase().includes(searchInput)
    );
    // Перерисовываем сетку с отфильтрованными товарами
    renderFilteredProducts(filteredProducts);
}

// Функция для отображения отфильтрованных товаров
function renderFilteredProducts(filteredProducts) {
    const productGrid = document.getElementById('productGrid');
    productGrid.innerHTML = '';

    filteredProducts.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';

        const img = document.createElement('img');
        img.src = product.img;
        img.alt = product.name;

        const addBtn = document.createElement('button');
        addBtn.className = 'add-btn';
        addBtn.textContent = 'ДОБАВИТЬ В 🛒';

        productCard.appendChild(img);
        productCard.appendChild(addBtn);
        productGrid.appendChild(productCard);
    });
}

// Инициализация
document.addEventListener('DOMContentLoaded', renderProducts);